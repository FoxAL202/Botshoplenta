
BOT_TOKEN = 'your_bot_token_here'
ADMIN_CHAT_ID = 123456789  # замените на свой Telegram user ID
